# TMCU Additional Bot — সহজ সেটআপ

## গুরুত্বপূর্ণ
- বটের Channel Join যাচাই করতে বটকে `@hoqueu` চ্যানেলের Admin করতে হবে।
- `BOT_TOKEN` গোপন রাখবেন। কাউকে চ্যাটে পাঠাবেন না।
- `ADMIN_ID` বর্তমানে `6925240757` দেওয়া আছে।
- `@hoqueu` সত্যিই একটি Telegram Channel কি না এবং বট সেখানে Admin কি না সেটি আগে নিশ্চিত করতে হবে।

## কী আছে
- `/start`, `/help`, `/profile`, `/admin`, `/add`, `/stats`
- Force Join + Verify
- ইউজারের Telegram profile photo (যদি Telegram API-তে পাওয়া যায়), নাম, username ও Chat ID
- বাংলাদেশ সময় অনুযায়ী শুভেচ্ছা ও সময়/তারিখ
- Facebook, TikTok, Instagram, YouTube, AI Print মেনু
- All Report Additional ও Mail Address সাবমেনু
- SQLite-এ কনটেন্ট সংরক্ষণ

## সীমাবদ্ধতা / Daily update
এই সংস্করণ নিজে থেকে ইন্টারনেট ঘেঁটে নতুন বা যাচাইকৃত রিপোর্টিং তথ্য বানায় না। Admin `/add` দিয়ে কনটেন্ট যোগ করবেন; বট সেগুলো দেখাবে এবং কোনটি সর্বশেষ দেখানো হয়েছে তা সংরক্ষণ করবে। প্রতিদিন নতুন তথ্য পেতে Admin-কে নতুন, যাচাইকৃত তথ্য যোগ করতে হবে। স্বয়ংক্রিয়ভাবে একই লেখা ঘুরিয়ে “নতুন” বলে দেখানো হয় না।

## নিরাপদ ব্যবহার
রিপোর্ট গাইডগুলো সত্য ঘটনা ও সংশ্লিষ্ট প্ল্যাটফর্মের অফিসিয়াল রিপোর্টিং পদ্ধতির জন্য ব্যবহার করুন। ভুয়া অভিযোগ, mass-reporting, impersonation বা কারও অ্যাকাউন্ট ক্ষতি করার অটোমেশন যোগ করা হয়নি। AI Print-এ সরকারি পরিচয়পত্রের নকল বানানোর বদলে স্পষ্টভাবে কাল্পনিক/নমুনা কার্ড ব্যবহার করুন।

## Render-এ চালানো
1. GitHub-এ একটি নতুন private repository খুলুন।
2. `bot.py`, `requirements.txt`, `render.yaml` আপলোড করুন।
3. Render-এ GitHub repository connect করে Background Worker deploy করুন।
4. Environment Variables-এ `BOT_TOKEN` হিসেবে BotFather-এর token দিন।
5. Render-এর persistent disk/SQLite storage ছাড়া redeploy-এ database হারাতে পারে; production-এ managed PostgreSQL ব্যবহার করুন।
6. Deploy logs-এ `Conflict: terminated by other getUpdates request` এলে একই token দিয়ে অন্য কোথাও bot চালু আছে কি না বন্ধ করুন।

## BotFather
Token নিতে `@BotFather` → `/mybots` → আপনার bot → API Token। Token কখনো কারও সঙ্গে শেয়ার করবেন না।
