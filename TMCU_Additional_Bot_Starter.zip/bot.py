import os
import sqlite3
from datetime import datetime
from zoneinfo import ZoneInfo

from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ContextTypes
)

BOT_TOKEN = os.environ["BOT_TOKEN"]
ADMIN_ID = int(os.environ.get("ADMIN_ID", "6925240757"))
CHANNEL = os.environ.get("CHANNEL", "@hoqueu")
CHANNEL_URL = os.environ.get("CHANNEL_URL", "https://t.me/hoqueu")
TZ = ZoneInfo("Asia/Dhaka")
DB = os.environ.get("DB_PATH", "bot.db")

CATEGORIES = {
    "facebook": "📘 Facebook",
    "tiktok": "🎵 TikTok",
    "instagram": "📸 Instagram",
    "youtube": "▶️ YouTube",
    "aiprint": "🖼️ AI Print",
}

def db():
    con = sqlite3.connect(DB)
    con.execute("""CREATE TABLE IF NOT EXISTS content (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category TEXT NOT NULL,
        kind TEXT NOT NULL,
        title TEXT NOT NULL,
        body TEXT NOT NULL,
        last_shown TEXT
    )""")
    con.commit()
    return con

def greeting(now):
    h = now.hour
    if 5 <= h < 12:
        return "🌞 শুভ সকাল!"
    if 12 <= h < 17:
        return "☀️ শুভ দুপুর!"
    if 17 <= h < 20:
        return "🌇 শুভ সন্ধ্যা!"
    return "🌙 শুভ রাত্রি!"

async def is_member(context, user_id):
    try:
        member = await context.bot.get_chat_member(CHANNEL, user_id)
        return member.status in ("member", "administrator", "creator")
    except Exception:
        return False

def join_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📢 Join Channel", url=CHANNEL_URL)],
        [InlineKeyboardButton("✅ আমি Join করেছি — Verify", callback_data="verify_join")]
    ])

def main_keyboard():
    rows = []
    for key, label in CATEGORIES.items():
        rows.append([InlineKeyboardButton(label, callback_data=f"cat:{key}")])
    return InlineKeyboardMarkup(rows)

async def show_join(update, text="বট ব্যবহার করতে আগে আমাদের চ্যানেলে Join করুন।"):
    msg = update.effective_message
    await msg.reply_text(text, reply_markup=join_keyboard())

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not await is_member(context, user.id):
        await show_join(update)
        return

    now = datetime.now(TZ)
    name = user.full_name or "বন্ধু"
    username = f"@{user.username}" if user.username else "Username নেই"
    caption = (
        f"{greeting(now)}\n"
        f"স্বাগতম, {name}!\n\n"
        f"👤 নাম: {name}\n"
        f"🔤 Username: {username}\n"
        f"🆔 Chat ID: {user.id}\n\n"
        f"🕒 সময়: {now.strftime('%I:%M:%S %p')}\n"
        f"📅 তারিখ: {now.strftime('%d-%m-%Y')}\n\n"
        "নিচের মেনু থেকে একটি বিভাগ নির্বাচন করুন।"
    )
    photos = await context.bot.get_user_profile_photos(user.id, limit=1)
    if photos.total_count:
        photo = photos.photos[0][-1].file_id
        await update.effective_message.reply_photo(
            photo=photo, caption=caption, reply_markup=main_keyboard()
        )
    else:
        await update.effective_message.reply_text(
            caption, reply_markup=main_keyboard()
        )

async def verify_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if await is_member(context, q.from_user.id):
        await q.message.reply_text("✅ Join যাচাই হয়েছে।", reply_markup=main_keyboard())
    else:
        await q.message.reply_text(
            "এখনো চ্যানেলে Join পাওয়া যায়নি। Join করে আবার Verify করুন।",
            reply_markup=join_keyboard()
        )

async def category_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not await is_member(context, q.from_user.id):
        await q.message.reply_text("আগে চ্যানেলে Join করুন।", reply_markup=join_keyboard())
        return
    category = q.data.split(":", 1)[1]
    label = CATEGORIES.get(category)
    if not label:
        return
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("📚 All Report Additional", callback_data=f"list:{category}:report")],
        [InlineKeyboardButton("✉️ Mail Address", callback_data=f"list:{category}:mail")],
        [InlineKeyboardButton("⬅️ Main Menu", callback_data="home")]
    ])
    await q.message.reply_text(f"{label}\nকোন বিভাগটি দেখতে চান?", reply_markup=keyboard)

async def list_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not await is_member(context, q.from_user.id):
        await q.message.reply_text("আগে চ্যানেলে Join করুন।", reply_markup=join_keyboard())
        return
    _, category, kind = q.data.split(":")
    con = db()
    rows = con.execute(
        "SELECT id,title FROM content WHERE category=? AND kind=? ORDER BY COALESCE(last_shown,''), id",
        (category, kind)
    ).fetchall()
    con.close()
    if not rows:
        await q.message.reply_text(
            "এই বিভাগে এখনো কোনো কনটেন্ট যোগ করা হয়নি। Admin পরে যোগ করতে পারবেন."
        )
        return
    buttons = [
        [InlineKeyboardButton(title[:60], callback_data=f"item:{item_id}")]
        for item_id, title in rows[:80]
    ]
    buttons.append([InlineKeyboardButton("⬅️ Back", callback_data=f"cat:{category}")])
    await q.message.reply_text("একটি বিষয় নির্বাচন করুন:", reply_markup=InlineKeyboardMarkup(buttons))

async def item_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not await is_member(context, q.from_user.id):
        await q.message.reply_text("আগে চ্যানেলে Join করুন।", reply_markup=join_keyboard())
        return
    item_id = int(q.data.split(":")[1])
    now = datetime.now(TZ).isoformat()
    con = db()
    row = con.execute("SELECT title,body FROM content WHERE id=?", (item_id,)).fetchone()
    if row:
        con.execute("UPDATE content SET last_shown=? WHERE id=?", (now, item_id))
        con.commit()
    con.close()
    if row:
        await q.message.reply_text(f"📌 {row[0]}\n\n{row[1]}")
    else:
        await q.message.reply_text("কনটেন্ট পাওয়া যায়নি।")

async def home_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not await is_member(context, q.from_user.id):
        await q.message.reply_text("আগে চ্যানেলে Join করুন।", reply_markup=join_keyboard())
    else:
        await q.message.reply_text("প্রধান মেনু:", reply_markup=main_keyboard())

async def add_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("এই কমান্ড শুধু Admin ব্যবহার করতে পারবেন।")
        return
    raw = update.message.text.partition(" ")[2]
    parts = raw.split("|", 3)
    if len(parts) != 4:
        await update.message.reply_text(
            "ব্যবহার:\n/add category|kind|title|body\n\n"
            "category: facebook/tiktok/instagram/youtube/aiprint\n"
            "kind: report অথবা mail\n"
            "উদাহরণ:\n/add facebook|report|অ্যাকাউন্ট সুরক্ষা|নিজের অ্যাকাউন্টের সমস্যা হলে অফিসিয়াল Help Center ব্যবহার করুন।"
        )
        return
    category, kind, title, body = [p.strip() for p in parts]
    if category not in CATEGORIES or kind not in ("report", "mail"):
        await update.message.reply_text("Category বা kind ভুল।")
        return
    con = db()
    con.execute(
        "INSERT INTO content(category,kind,title,body) VALUES(?,?,?,?)",
        (category, kind, title, body)
    )
    con.commit()
    con.close()
    await update.message.reply_text("✅ কনটেন্ট যোগ হয়েছে।")

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("শুধু Admin-এর জন্য।")
        return
    con = db()
    count = con.execute("SELECT COUNT(*) FROM content").fetchone()[0]
    con.close()
    await update.message.reply_text(f"📊 মোট সংরক্ষিত কনটেন্ট: {count}")

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("আপনি Admin নন।")
        return
    await update.message.reply_text(
        "⚙️ Admin Panel\n\n"
        "/add — নতুন কনটেন্ট যোগ\n"
        "/stats — কনটেন্ট সংখ্যা\n\n"
        "নিরাপত্তা: শুধু নির্ধারিত Admin ID এই কমান্ড ব্যবহার করতে পারবেন।"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "/start — বট শুরু\n/help — সাহায্য\n/profile — প্রোফাইল কার্ড\n\n"
        "কনটেন্ট যোগ করতে Admin: /add"
    )

async def profile_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)

def main():
    db().close()
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("profile", profile_command))
    app.add_handler(CommandHandler("admin", admin_command))
    app.add_handler(CommandHandler("add", add_command))
    app.add_handler(CommandHandler("stats", stats_command))
    app.add_handler(CallbackQueryHandler(verify_callback, pattern="^verify_join$"))
    app.add_handler(CallbackQueryHandler(category_callback, pattern="^cat:"))
    app.add_handler(CallbackQueryHandler(list_callback, pattern="^list:"))
    app.add_handler(CallbackQueryHandler(item_callback, pattern="^item:"))
    app.add_handler(CallbackQueryHandler(home_callback, pattern="^home$"))
    app.run_polling()

if __name__ == "__main__":
    main()
